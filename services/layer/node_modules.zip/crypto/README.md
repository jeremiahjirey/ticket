# Deprecated Package

This package is no longer supported and has been deprecated. To avoid malicious use, npm is hanging on to the package name.

It's now a built-in Node module. If you've depended on crypto, you should switch to the one that's built-in.

Please contact support@npmjs.com if you have questions about this package.
